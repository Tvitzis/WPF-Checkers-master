# WPF-Checkers
A checkers game built on top of WPF in C#. 

this game was created to learn more about WPF and how to interact with items on the window.

there are three windows available consisting of the game board along with an options window and a home window. 

 The options window is a basic options page that allows the user to change the "theme" of the the checks on the board before the game starts. the base option is to randomly generate colors for each player.
 
 at this time only 2-player mode is available. there is no single player mode against the computer. this may come at a later date.
 
 

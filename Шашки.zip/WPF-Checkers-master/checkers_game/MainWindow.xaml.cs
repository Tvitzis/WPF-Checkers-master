﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace checkers_game
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        #region private variables
        // создаёт двумерный массив, который хранит текущее расположение всех шашек на доске. Это используется для проверки ходов игроков
        private CheckerType[,] Board_array;

        // хранит логическую переменную для отслеживания, какой игрок сейчас ходит
        private bool player_one_turn;

        // переменная будет переключена на true, если первый клик игрока - это кнопка, содержащая шашку, принадлежащую ему
        private bool players_second_click;

        // итерируемый тип кнопок
        private List<Button> buttonList;

        // хранит ссылку на предыдущую нажатую кнопку, чтобы её можно было обновить, если сделан допустимый ход
        private Button prevButton;

        // строка и столбец сетки текущей кнопки и предыдущей нажатой кнопки
        private int row, column, prevRow, prevCol;

        private int p1_check_count, p2_check_count;

        // переменные для цвета шашек
        private Brush p1_color;
        private Brush p2_color;

        #endregion

        public MainWindow(Brush p1_color, Brush p2_color)
        {
            InitializeComponent();
            this.p1_color = p1_color;
            this.p2_color = p2_color;

            p1_identifier.Foreground = p1_color;
            p2_identifier.Foreground = p2_color;

            NewGame();
        }

        private void NewGame()
        {
            // получить список кнопок для дальнейшего доступа
            buttonList = Board.Children.Cast<Button>().ToList();

            // создать пустой массив доски с 64 плитками. Это включает черные и белые плитки.
            Board_array = new CheckerType[8, 8];

            // установить шашки на доске 
            for (int row = 0; row < 8; row++)
            {
                if (row == 0 || row == 2 || row == 6) // если строка равна 0, 2 или 6 
                {
                    for (int col = 0; col < 7; col += 2) // разместить шашки на четных плитках, начиная с 0
                    {
                        if (row == 0 || row == 2) { Board_array[row, col] = CheckerType.P2_check; } // строки 0 и 2 заполнены шашками игрока 2
                        // строка 6 заполнена шашками игрока 1
                        else { Board_array[row, col] = CheckerType.P1_check; }
                    }
                }

                if (row == 1 || row == 5 || row == 7)
                {
                    for (int col = 1; col < 8; col += 2) // разместить шашки на нечетных плитках, начиная с 1
                    {
                        if (row == 5 || row == 7) { Board_array[row, col] = CheckerType.P1_check; } // строки 5 и 7 заполнены шашками игрока 1
                        // строка 1 заполнена шашками игрока 2
                        else { Board_array[row, col] = CheckerType.P2_check; }
                    }
                }
            } // конец построения доски

            // инициализация каждой из приватных переменных
            player_one_turn = true; // игрок 1 - текущий игрок
            players_second_click = false;
            row = -1;
            column = 0;
            prevRow = 0;
            prevCol = 0;

            p1_check_count = 12;
            p2_check_count = 12;

            int counter = 0;

            // пройтись по каждой кнопке и установить начальную настройку с помощью лямбда-функции
            buttonList.ForEach(button =>
            {
                // для кнопок игрока 2. заполнить изображениями шашек (верхние три строки доски)
                if (counter < 12)
                {
                    button.Content = "•";
                    button.Foreground = p2_color;
                    counter++;
                }
                // для кнопок игрока 1. заполнить изображениями шашек (нижние три строки доски)
                else if (counter >= 20 && counter < 32)
                {
                    button.Content = "•";
                    button.Foreground = p1_color;
                    counter++;
                }
                else
                {
                    button.Content = string.Empty;
                    counter++; // сбросить кнопку на пустую
                }
            });
        } // конец метода новой игры

        /*
         * 
         * ********************вспомогательные функции ниже*******************
         * 
         */

        private void borderChangeOnCLick(Button button)
        {
            // когда кнопка нажата, граница изменяется, чтобы помочь пользователю увидеть, какую кнопку они нажали
            button.BorderThickness = new Thickness(3, 3, 3, 3);
            button.BorderBrush = Brushes.Snow;
        }

        private void borderChangeBack(Button button)
        {
            // сбросить толщину и цвет границы
            button.BorderThickness = new Thickness(1, 1, 1, 1);
            button.BorderBrush = Brushes.SlateGray;
        }

        private void updateBoardGui()
        {
            /*
             * 
             * используется для обновления графического интерфейса игрового поля при прыжках шашек. 
             */
            buttonList.ForEach(button =>
            {
                int row = Grid.GetRow(button);
                int col = Grid.GetColumn(button);

                if (Board_array[row, col] == CheckerType.P1_check)
                {
                    button.Content = "•";
                    button.Foreground = p1_color;
                }
                else if (Board_array[row, col] == CheckerType.P1_king)
                {
                    button.Content = "♛";
                    button.Foreground = p1_color;
                }
                else if (Board_array[row, col] == CheckerType.P2_check)
                {
                    button.Content = "•";
                    button.Foreground = p2_color;
                }
                else if (Board_array[row, col] == CheckerType.P2_king)
                {
                    button.Content = "♚";
                    button.Foreground = p2_color;
                }
                else
                {
                    button.Content = "";
                }
            });
        }

        // функция, которая определяет, доступны ли дополнительные прыжки после начального прыжка. 
        // вернет true, если найдены, и вернет false в противном случае
        private bool p1_jump_available()
        {
            if (row - 2 >= 0 && column - 2 >= 0 && Board_array[row - 2, column - 2] == CheckerType.Free && (Board_array[row - 1, column - 1] == CheckerType.P2_check || Board_array[row - 1, column - 1] == CheckerType.P2_king))
            {
                // проверьте, можно ли сделать еще один ход, переместившись влево на 2 и вверх на 2
                return true;
            }
            else if (row - 2 >= 0 && column + 2 <= 7 && Board_array[row - 2, column + 2] == CheckerType.Free && (Board_array[row - 1, column + 1] == CheckerType.P2_check || Board_array[row - 1, column + 1] == CheckerType.P2_king))
            {
                // проверьте, можно ли сделать еще один ход, переместившись вправо на 2 и вверх на 2
                return true;
            }
            else
            {
                // больше не может быть сделано допустимых прыжков, поэтому ход игрока завершен
                return false;
            }
        }

        // функция, которая определяет, доступны ли дополнительные прыжки после начального прыжка. 
        // вернет true, если найдены, и вернет false в противном случае
        private bool p2_jump_available()
        {
            if (row + 2 <= 7 && column + 2 <= 7 && Board_array[row + 2, column + 2] == CheckerType.Free && (Board_array[row + 1, column + 1] == CheckerType.P1_check || Board_array[row + 1, column + 1] == CheckerType.P1_king))
            {
                // проверьте, можно ли сделать еще один ход, переместившись вправо на 2 и вниз на 2
                return true;
            }
            else if (row + 2 <= 7 && column - 2 >= 0 && Board_array[row + 2, column - 2] == CheckerType.Free && (Board_array[row + 1, column - 1] == CheckerType.P1_check || Board_array[row + 1, column - 1] == CheckerType.P1_king))
            {
                // проверьте, можно ли сделать еще один ход, переместившись влево на 2 и вниз на 2
                return true;
            }
            else
            {
                // больше не может быть сделано допустимых прыжков
                return false;
            }
        }

        // функция, аналогичная p1_jump_available(), но проверяет, доступны ли прыжки в любом из четырех направлений.
        // эта функция используется для обоих игроков, так как короли могут двигаться в любом направлении, независимо от владельца
        private bool more_king_jump_available()
        {
            if (player_one_turn)
            {
                if (row - 2 >= 0 && column - 2 >= 0 && Board_array[row - 2, column - 2] == CheckerType.Free && (Board_array[row - 1, column - 1] == CheckerType.P2_check || Board_array[row - 1, column - 1] == CheckerType.P2_king))
                {
                    // проверьте, можно ли сделать еще один ход, переместившись влево на 2 и вверх на 2
                    return true;
                }
                else if (row - 2 >= 0 && column + 2 <= 7 && Board_array[row - 2, column + 2] == CheckerType.Free && (Board_array[row - 1, column + 1] == CheckerType.P2_check || Board_array[row - 1, column + 1] == CheckerType.P2_king))
                {
                    // проверьте, можно ли сделать еще один ход, переместившись вправо на 2 и вверх на 2
                    return true;
                }
                else if (row + 2 <= 7 && column - 2 >= 0 && Board_array[row + 2, column - 2] == CheckerType.Free && (Board_array[row + 1, column - 1] == CheckerType.P2_check || Board_array[row + 1, column - 1] == CheckerType.P2_king))
                {
                    // проверьте, можно ли сделать еще один ход, переместившись влево на 2 и вниз на 2
                    return true;
                }
                else if (row + 2 <= 7 && column + 2 <= 7 && Board_array[row + 2, column + 2] == CheckerType.Free && (Board_array[row + 1, column + 1] == CheckerType.P2_check || Board_array[row + 1, column + 1] == CheckerType.P2_king))
                {
                    // проверьте, можно ли сделать еще один ход, переместившись вправо на 2 и вниз на 2
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                if (row - 2 >= 0 && column - 2 >= 0 && Board_array[row - 2, column - 2] == CheckerType.Free && (Board_array[row - 1, column - 1] == CheckerType.P1_check || Board_array[row - 1, column - 1] == CheckerType.P1_king))
                {
                    // проверьте, можно ли сделать еще один ход, переместившись влево на 2 и вверх на 2
                    return true;
                }
                else if (row - 2 >= 0 && column + 2 <= 7 && Board_array[row - 2, column + 2] == CheckerType.Free && (Board_array[row - 1, column + 1] == CheckerType.P1_check || Board_array[row - 1, column + 1] == CheckerType.P1_king))
                {
                    // проверьте, можно ли сделать еще один ход, переместившись вправо на 2 и вверх на 2
                    return true;
                }
                else if (row + 2 <= 7 && column - 2 >= 0 && Board_array[row + 2, column - 2] == CheckerType.Free && (Board_array[row + 1, column - 1] == CheckerType.P1_check || Board_array[row + 1, column - 1] == CheckerType.P1_king))
                {
                    // проверьте, можно ли сделать еще один ход, переместившись влево на 2 и вниз на 2
                    return true;
                }
                else if (row + 2 <= 7 && column + 2 <= 7 && Board_array[row + 2, column + 2] == CheckerType.Free && (Board_array[row + 1, column + 1] == CheckerType.P1_check || Board_array[row + 1, column + 1] == CheckerType.P1_king))
                {
                    // проверьте, можно ли сделать еще один ход, переместившись вправо на 2 и вниз на 2
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        // функция для проверки, была ли шашка перемещена на часть доски, которая позволяет ей стать королем.
        private bool Is_kinged()
        {
            // игрок 1 достиг верхней части и должен стать королем
            System.Console.WriteLine("is kinged row " + row);

            if (row == 0 && Board_array[prevRow, prevCol] == CheckerType.P1_check)
            {
                System.Console.WriteLine("should be kinged");
                Board_array[row, column] = CheckerType.P1_king;
                Board_array[prevRow, prevCol] = CheckerType.Free;

                updateBoardGui();
                return true;
            }
            else if (row == 7 && Board_array[prevRow, prevCol] == CheckerType.P2_check)
            {
                // игрок 2 достиг нижней части и должен стать королем
                Board_array[row, column] = CheckerType.P2_king;
                Board_array[prevRow, prevCol] = CheckerType.Free;

                updateBoardGui();
                return true;
            }
            else
            {
                // шашка не стала королем
                return false;
            }
        }

        // функция, созданная для соблюдения принципов DRY, так как короли могут двигаться в любом направлении, независимо от владельца
        private bool is_normal_king_move()
        {
            if (Board_array[row, column] == CheckerType.Free && (row - prevRow == 1 || row - prevRow == -1) && (column - prevCol == 1 || column - prevCol == -1))
            {
                Board_array[row, column] = Board_array[prevRow, prevCol];
                Board_array[prevRow, prevCol] = CheckerType.Free;
                return true;
            }
            else
            {
                return false;
            }
        }

        // функция, которая проверяет, является ли попытка прыжка короля допустимой в зависимости от игрока
        private bool is_valid_king_jump()
        {
            if (player_one_turn)
            {
                // ход игрока 1
                if (Board_array[row, column] == CheckerType.Free && row - prevRow == 2 && column - prevCol == 2)
                {
                    if (Board_array[row - 1, column - 1] == CheckerType.P2_check || Board_array[row - 1, column - 1] == CheckerType.P2_king)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else if (Board_array[row, column] == CheckerType.Free && row - prevRow == 2 && column - prevCol == -2)
                {
                    if (Board_array[row - 1, column + 1] == CheckerType.P2_check || Board_array[row - 1, column + 1] == CheckerType.P2_king)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else if (Board_array[row, column] == CheckerType.Free && row - prevRow == -2 && column - prevCol == 2)
                {
                    if (Board_array[row + 1, column - 1] == CheckerType.P2_check || Board_array[row + 1, column - 1] == CheckerType.P2_king)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else if (Board_array[row, column] == CheckerType.Free && row - prevRow == -2 && column - prevCol == -2)
                {
                    if (Board_array[row + 1, column + 1] == CheckerType.P2_check || Board_array[row + 1, column + 1] == CheckerType.P2_king)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }
            }
            else
            {
                // ход игрока 2
                if (Board_array[row, column] == CheckerType.Free && row - prevRow == 2 && column - prevCol == 2)
                {
                    if (Board_array[row - 1, column - 1] == CheckerType.P1_check || Board_array[row - 1, column - 1] == CheckerType.P1_king)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else if (Board_array[row, column] == CheckerType.Free && row - prevRow == 2 && column - prevCol == -2)
                {
                    if (Board_array[row - 1, column + 1] == CheckerType.P1_check || Board_array[row - 1, column + 1] == CheckerType.P1_king)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else if (Board_array[row, column] == CheckerType.Free && row - prevRow == -2 && column - prevCol == 2)
                {
                    if (Board_array[row + 1, column - 1] == CheckerType.P1_check || Board_array[row + 1, column - 1] == CheckerType.P1_king)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else if (Board_array[row, column] == CheckerType.Free && row - prevRow == -2 && column - prevCol == -2)
                {
                    if (Board_array[row + 1, column + 1] == CheckerType.P1_check || Board_array[row + 1, column + 1] == CheckerType.P1_king)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }
            }
        }

        private void End_turn()
        {
            Is_kinged(); // проверьте, является ли последний ход игрока ходом с коронованием

            players_second_click = !players_second_click;
            player_one_turn = !player_one_turn;

            // после переключения игроков определите текущего игрока и отобразите это в окне
            if (player_one_turn)
            {
                current_player.Text = "Player 1 turn";
            }
            else
            {
                current_player.Text = "Player 2 turn";
            }
        }

        private void invalid_choice()
        {
            players_second_click = false;
            borderChangeBack(prevButton);
        }

        private bool game_over()
        {
            if (p1_check_count == 0 || p2_check_count == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /*
         **************** Конец вспомогательных функций***************************
         * 
         * 
         *************** обработчик событий нажатия кнопки********************
         *    содержит всю игровую логику для шашек  
         */
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // если игра закончилась, появится текстовое окно, чтобы сообщить о победителе
            // после этого игровое окно закрывается, и инициализируется и отображается главное окно

            if (game_over())
            {
                if (p1_check_count > 0) // игрок 1 выиграл 
                {
                    MessageBoxResult result = MessageBox.Show("ПЕРВЫЙ ИГРОК ВЫИГРАЛ!", "ИГРА ОКОНЧЕНА");
                }
                else // игрок 2 выиграл
                {
                    MessageBoxResult result = MessageBox.Show("ВТОРОЙ ИГРОК ВЫИГРАЛ", "ИГРА ОКОНЧЕНА");
                }

                Window1 window = new Window1();
                this.Visibility = Visibility.Collapsed; // скрыть текущее окно
                window.Show(); // показать объект главного окна
                this.Close();
            }

            var button = (Button)sender;

            // получить строку и столбец нажатой кнопки, чтобы её можно было найти в массиве Board_array и применить логику
            column = Grid.GetColumn(button);
            row = Grid.GetRow(button);

            // сейчас ход игрока 1
            if (player_one_turn)
            {
                // игрок нажал на шашку, принадлежащую ему, и хочет её переместить
                if (players_second_click)
                {
                    prevRow = Grid.GetRow(prevButton);
                    prevCol = Grid.GetColumn(prevButton);
                    if (Board_array[prevRow, prevCol] == CheckerType.P1_check)
                    {
                        // шашка - обычная шашка

                        // проверьте, сделал ли игрок обычный ход
                        if (Board_array[row, column] == CheckerType.Free && (row - prevRow == -1) && (column - prevCol == -1 || column - prevCol == 1))
                        {
                            if (!Is_kinged())
                            {
                                // пространство свободно и это допустимый ход, а не коронованный ход
                                Board_array[row, column] = CheckerType.P1_check;
                                Board_array[prevRow, prevCol] = CheckerType.Free;
                                button.Content = "•";
                                button.Foreground = p1_color;
                                borderChangeBack(prevButton);
                                prevButton.Content = "";
                            }

                            // завершить ход игрока 1 после допустимого хода
                            End_turn();
                            borderChangeBack(prevButton);
                        }
                        else if (Board_array[row, column] == CheckerType.Free && (row - prevRow == -2) && (column - prevCol == -2))
                        {
                            // если шашка противника открыта для прыжка
                            if (Board_array[row + 1, column + 1] == CheckerType.P2_check || Board_array[row + 1, column + 1] == CheckerType.P2_king)
                            {
                                p2_check_count--; // уменьшить количество шашек игрока 2

                                // прыгнуть через шашку противника
                                Board_array[row + 1, column + 1] = CheckerType.Free;

                                if (Is_kinged())
                                {
                                    End_turn();
                                    borderChangeBack(prevButton);
                                }
                                else
                                {
                                    Board_array[row, column] = CheckerType.P1_check;
                                    Board_array[prevRow, prevCol] = CheckerType.Free;

                                    // сбросить границу кнопки и обновить игровую доску
                                    borderChangeBack(prevButton);
                                    updateBoardGui();

                                    if (p1_jump_available())
                                    {
                                        // проверьте, можно ли сделать еще один прыжок, и если да, то сделайте текущую кнопку предыдущей кнопкой и дайте игроку возможность снова ходить
                                        prevButton = button;
                                        borderChangeOnCLick(button);
                                    }
                                    else
                                    {
                                        // больше не может быть сделано допустимых прыжков, поэтому ход игрока завершен
                                        End_turn();
                                        borderChangeBack(prevButton);
                                    }
                                }
                            }
                        }
                        else if (Board_array[row, column] == CheckerType.Free && (row - prevRow == -2) && (column - prevCol == 2))
                        {
                            if (Board_array[row + 1, column - 1] == CheckerType.P2_check || Board_array[row + 1, column - 1] == CheckerType.P2_king)
                            {
                                p2_check_count--; // уменьшить количество шашек игрока 2
                                // прыгнуть через шашку противника с доски

                                Board_array[row + 1, column - 1] = CheckerType.Free;

                                if (Is_kinged())
                                {
                                    // шашка была коронована, поэтому это конец хода игрока
                                    End_turn();
                                    borderChangeBack(prevButton);
                                }
                                else
                                { // шашка не была коронована после прыжка
                                    Board_array[row, column] = CheckerType.P1_check;
                                    Board_array[prevRow, prevCol] = CheckerType.Free;

                                    // сбросить границу кнопки и обновить игровую доску
                                    borderChangeBack(prevButton);
                                    updateBoardGui();

                                    if (p1_jump_available())
                                    {
                                        // проверьте, можно ли сделать еще один прыжок, и если да, то сделайте текущую кнопку предыдущей кнопкой и дайте игроку возможность снова ходить
                                        prevButton = button;
                                        borderChangeOnCLick(button);
                                    }
                                    else
                                    {
                                        // больше не может быть сделано допустимых прыжков, поэтому ход игрока завершен
                                        End_turn();
                                        borderChangeBack(prevButton);
                                    }
                                }
                            }
                        }
                        else
                        {
                            // не была выбрана допустимая кнопка, поэтому сбросить ход
                            invalid_choice();
                        }
                    }
                    else
                    {
                        // шашка - король
                        if (is_normal_king_move())
                        {
                            button.Content = "♛";
                            button.Foreground = p1_color;

                            prevButton.Content = "";

                            borderChangeBack(prevButton);

                            End_turn();
                        }
                        else if (is_valid_king_jump())
                        {
                            p2_check_count--; // уменьшить количество шашек игрока 2

                            // вычислить строку и столбец перепрыгнутой шашки из любого направления 
                            // это потому, что король может двигаться в любом направлении
                            // пример: row = 5 prevRow = 7: тогда 5 + ((5 - 7) * -.5) = 6, что является строкой перепрыгнутой шашки
                            int jumped_row = (int)(row + ((row - prevRow) * -.5));
                            
                            int jumped_col = (int)(column + ((column - prevCol) * -.5));

                            Board_array[row, column] = CheckerType.P1_king;

                            System.Console.WriteLine("значение перепрыгнутой шашки " + (jumped_row) + "  " + (jumped_col));
                            Board_array[jumped_row, jumped_col] = CheckerType.Free;

                            Board_array[prevRow, prevCol] = CheckerType.Free;

                            borderChangeBack(prevButton);
                            updateBoardGui();

                            if (more_king_jump_available())
                            {
                                // проверьте, можно ли сделать еще один прыжок, и если да, то сделайте текущую кнопку предыдущей кнопкой и дайте игроку возможность снова ходить
                                prevButton = button;
                                borderChangeOnCLick(button);
                            }
                            else
                            {
                                // больше не может быть сделано допустимых прыжков, поэтому ход игрока завершен
                                End_turn();
                                borderChangeBack(prevButton);
                            }
                        }
                        else
                        {
                            invalid_choice();
                        }
                    }
                }
                // это первый клик игрока
                else
                {
                    // если нажата кнопка, принадлежащая игроку 1, шашка или король, то разрешить движение
                    if (Board_array[row, column] == CheckerType.P1_check || Board_array[row, column] == CheckerType.P1_king)
                    {
                        prevButton = button; // сохранить текущую кнопку, чтобы к ней можно было обратиться позже
                        borderChangeOnCLick(button);
                        players_second_click = true;
                    }
                }
            }
            // ход игрока 2
            else
            {
                // игрок нажал на шашку, принадлежащую ему, и хочет её переместить
                if (players_second_click)
                {
                    prevRow = Grid.GetRow(prevButton);
                    prevCol = Grid.GetColumn(prevButton);
                    if (Board_array[prevRow, prevCol] == CheckerType.P2_check)
                    {
                        if (Board_array[row, column] == CheckerType.Free && (row - prevRow == 1) && (column - prevCol == -1 || column - prevCol == 1))
                        {
                            if (!Is_kinged())
                            {
                                Board_array[row, column] = CheckerType.P2_check;

                                Board_array[prevRow, prevCol] = CheckerType.Free;

                                button.Content = "•";
                                button.Foreground = p2_color;
                                borderChangeBack(prevButton);
                                prevButton.Content = "";
                            }

                            // завершить ход игрока 2 после допустимого хода
                            End_turn();
                            borderChangeBack(prevButton);
                        }
                        else if (Board_array[row, column] == CheckerType.Free && (row - prevRow == 2) && column - prevCol == -2)
                        {
                            // шашка между предыдущей кнопкой и текущей кнопкой - это шашка игрока 1 или король 
                            if (Board_array[row - 1, column + 1] == CheckerType.P1_check || Board_array[row - 1, column + 1] == CheckerType.P1_king)
                            {
                                p1_check_count--; // уменьшить количество шашек игрока 1

                                Board_array[row - 1, column + 1] = CheckerType.Free;

                                if (Is_kinged())
                                {
                                    End_turn();
                                    borderChangeBack(prevButton);
                                }
                                else
                                {
                                    Board_array[row, column] = CheckerType.P2_check;
                                    Board_array[prevRow, prevCol] = CheckerType.Free;

                                    borderChangeBack(prevButton);
                                    updateBoardGui();

                                    if (p2_jump_available())
                                    {
                                        borderChangeOnCLick(button);
                                        prevButton = button;
                                    }
                                    else
                                    {
                                        End_turn();
                                        borderChangeBack(prevButton);
                                    }
                                }
                            }
                        }
                        else if (Board_array[row, column] == CheckerType.Free && (row - prevRow == 2) && column - prevCol == 2)
                        {
                            p1_check_count--; // уменьшить количество шашек игрока 1

                            Board_array[row - 1, column - 1] = CheckerType.Free;

                            if (Is_kinged())
                            {
                                End_turn();
                                borderChangeBack(prevButton);
                            }
                            else
                            {
                                Board_array[row, column] = CheckerType.P2_check;
                                Board_array[prevRow, prevCol] = CheckerType.Free;

                                borderChangeBack(prevButton);
                                updateBoardGui();

                                if (p2_jump_available())
                                {
                                    borderChangeOnCLick(button);
                                    prevButton = button;
                                }
                                else
                                {
                                    End_turn();
                                    borderChangeBack(prevButton);
                                }
                            }
                        }
                        else
                        {
                            // не была выбрана допустимая кнопка, поэтому сбросить ход
                            invalid_choice();
                        }
                    }
                    else
                    {
                        // шашка выбрана - это король 
                        if (is_normal_king_move())
                        {
                            button.Content = "♚";
                            button.Foreground = p2_color;

                            prevButton.Content = "";

                            borderChangeBack(prevButton);

                            End_turn();
                        }
                        else if (is_valid_king_jump())
                        {
                            p1_check_count--; // уменьшить количество шашек игрока 1

                            // вычислить строку и столбец перепрыгнутой шашки из любого направления 
                            int jumped_row = (int)(row + ((row - prevRow) * -.5));
                            int jumped_col = (int)(column + ((column - prevCol) * -.5));

                            Board_array[row, column] = CheckerType.P2_king;

                            System.Console.WriteLine("значение перепрыгнутой шашки " + (jumped_row) + "  " + (jumped_col));
                            Board_array[jumped_row, jumped_col] = CheckerType.Free;

                            Board_array[prevRow, prevCol] = CheckerType.Free;

                            borderChangeBack(prevButton);
                            updateBoardGui();

                            if (more_king_jump_available())
                            {
                                // проверьте, можно ли сделать еще один прыжок, и если да, то сделайте текущую кнопку предыдущей кнопкой и дайте игроку возможность снова ходить
                                prevButton = button;
                                borderChangeOnCLick(button);
                            }
                            else
                            {
                                // больше не может быть сделано допустимых прыжков, поэтому ход игрока завершен
                                End_turn();
                                borderChangeBack(prevButton);
                            }
                        }
                        else
                        {
                            invalid_choice();
                        }
                    }
                }
                // это первый клик игрока
                else
                {
                    // если нажата кнопка, принадлежащая игроку 2, шашка или король, то разрешить движение
                    if (Board_array[row, column] == CheckerType.P2_check || Board_array[row, column] == CheckerType.P2_king)
                    {
                        prevButton = button; // сохранить текущую кнопку, чтобы к ней можно было обратиться в следующем клике
                        players_second_click = true;
                        borderChangeOnCLick(button);
                    }
                }
            }
        }
    }
}
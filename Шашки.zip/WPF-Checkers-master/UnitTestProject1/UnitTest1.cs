﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Windows; // Для использования Window
using System.Windows.Media; // Для использования Brush
using checkers_game; // Убедитесь, что этот namespace содержит класс MainWindow

namespace UnitTestProject1
{
    [TestClass]
    public class MainWindowTests
    {
        private MainWindow mainWindow;

        [TestMethod]
        public void MainWindow_ShouldBeInstantiatedAndVisible()
        {
            // Arrange
            mainWindow = new MainWindow(Brushes.White, Brushes.Black); // Создаем экземпляр MainWindow

            // Act
            mainWindow.Show(); // Показываем окно

            // Assert
            Assert.IsNotNull(mainWindow, "Main window should be instantiated."); // Проверяем, что экземпляр не равен null
            Assert.IsTrue(mainWindow.IsVisible, "Main window should be visible."); // Проверяем, что окно видно
        }
    }
}